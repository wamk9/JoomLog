/* default inserted */
INSERT INTO `#__joomlog_type` (`id`, `title`, `description`) VALUES
(5, 'SECURITY', 'N/A');