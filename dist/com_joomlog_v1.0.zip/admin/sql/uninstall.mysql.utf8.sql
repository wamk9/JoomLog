DROP TABLE IF EXISTS `#__joomlog_log`;
DROP TABLE IF EXISTS `#__joomlog_type`;
DROP TABLE IF EXISTS `#__joomlog_version`;

